/****   Copyright (c) 2001-2003  Alexandros V. Gerbessiotis
 ****
 ****   Permission to use, copy, modify, and distribute this software,
 ****   and to incorporate it, in whole or in part, into other software,
 ****   is hereby granted without fee, provided that
 ****     (1) the above copyright notice and this permission notice appear in
 ****         all copies of the source code, and the above copyright notice
 ****         appear in clearly visible form on all supporting documentation
 ****         and distribution media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects; use this code on your own personal risk
 ****/

#include	"rdxai.h"	
#ifdef MPILIB

// ** Data Receive Routine *************************
void Ncheck ( int  *Data, int Size, int *Rcount)
{
  int recTemp[Size];
  int j, flag, count;
  MPI_Status status;

  do {
      MPI_Iprobe ( MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&flag,&status);
      if ( flag ) {
          MPI_Recv (&recTemp, Size, MPI_INT  , 
               status.MPI_SOURCE, 1, MPI_COMM_WORLD, &status);
          MPI_Get_count ( &status, MPI_INT  , &count );
          j = recTemp[count-1];
          memcpy(&Data[j], &recTemp[0],(count-1)*sizeof(unsigned int));
          *Rcount -= --count;
      }
  } while ( flag );
}


/*** HERE **/
void mprdx4 (unsigned int *src,int nn)
{
 register int pid;    /* processor id */
 register int nprocs; /* number of processors available */
 register int rounds;
 int count[256],tcount[256],ccount[256], total[256];
 register int i,j,dpf,dpl,first,last,size,offset,nbytes,r,m;
 int N,n;
 data *out;
 unsigned int mask;
 data **buffer;
 unsigned int shifts[4],shift;
 int mpistat,mpistat1,mpistat2;
 int Rcount;
 MPI_Request request;
 MPI_Status  status;
 unsigned int temp;

 pid = AIPID(); nprocs = AINPROCS();
 r=256;
 n=nn;
 nbytes=sizeof(unsigned int);
 shifts[0]=0;shifts[1]=8;shifts[2]=16;shifts[3]=24;
 mpistat=mpistat1=mpistat2=-10;

 N=n; 
 out = (unsigned int *) malloc((N+1)*nbytes);
#ifdef SANITY_CHECK
  check_if_null((void *)out,"rdxsrt4","out");
#endif

 AIOREGISTER((char *)ccount,r*sizeof(int));
 AIOREGISTER((char *)total,r*sizeof(int));
 AIOCOMMIT();
for(rounds=0;rounds<4;rounds++) { /**********ROUND LOOP****/
 Rcount=N;
 shift=shifts[rounds];
 memset(count,0,r*sizeof(int));
 for(i=0;i<n;++i)
    count[(src[i]>>shift) & 0x000000FF]++; /* count */
 memcpy(tcount,count,r*sizeof(int)); /* copy counters for later use */
 for(j=1;j<r;++j)
    count[j] +=count[j-1]; /* determine position of keys in out */
 for(i=n-1;i>=0;--i) {
   m=--count[(src[i]>>shift) & 0x000000FF];
   out[m]=src[i];         /* complete count sort */
 }

 memcpy(count,tcount,r*sizeof(int));  /* recover count */
 AIOINIT((char *)ccount);
 AIOINIT((char *)total);
 /* Determine global position of each key; ccount ppf, total global sums  */
 ai2scan(oper_add,r,(char *)count,(char *)ccount,(char*) total,sizeof(int));
 for(j=1;j<r;++j)
   total[j]=total[j]+total[j-1];
 for(j=1;j<r;++j)
   ccount[j]=ccount[j]+ total[j-1]; /* position of 0..r-1 in global array */
 for(j=1;j<r;++j)
    count[j] +=count[j-1]; /* repeat count sort steps */


 for(j=0;j<r;j++) {
   first=ccount[j]-tcount[j]; /* first position */
   last =ccount[j]-1;         /* last  position  to store [j]'s */
   dpf = first / N;           /* first processor */
   dpl = last  / N;           /* last  processor to store [j]'s */
   if (first <=last) {        /* do there exist [j] keys? */
   if (dpf==dpl){ /* if yes, check if they all go to same processor */
      /* DEBUG1; */
      if (tcount[j]>0) { /* no need for communication if 0 */
/*
      AIOHPPUT(dpf,(char *)&out[(count[j]-tcount[j])],(char *)src,
              nbytes*(first-dpf*N), tcount[j]*nbytes);
*/
      if (pid==dpf) {
        memcpy((char *)&src[first-dpf*N],(char *)&out[(count[j]-tcount[j])],tcount[j]*nbytes);
        Rcount -= tcount[j];
      } else{
      temp= out[count[j]];
      out[count[j]]=(first-dpf*N);
      MPI_Isend((void *)&out[(count[j]-tcount[j])], (1+tcount[j]),MPI_INT ,dpf,
                1,MPI_COMM_WORLD,&request);
      out[count[j]]=temp;
      Ncheck((int *)src,(N+1),&Rcount);
      }
      }
   }
   else { /* if they do not go to the same processor */
      size=dpl*N-first; /* first processor receives some */
      /* DEBUG2; */
      if (size >0) {
/*
        AIOHPPUT(dpf,(char *)&out[(count[j]-tcount[j])],(char *)src,
               nbytes*(N-size),size*nbytes);
*/
      if (pid==dpf){
       memcpy((char *)&src[N-size],(char *)&out[(count[j]-tcount[j])],size*nbytes);
       Rcount -= size ;
      }
      else {
      temp= out[(count[j]-tcount[j])+size];
      out[(count[j]-tcount[j])+size]=(N-size);
      MPI_Isend((void *)&out[(count[j]-tcount[j])], (1+size),MPI_INT ,dpf,
                1,MPI_COMM_WORLD,&request);
      out[(count[j]-tcount[j])+size]=temp;
      Ncheck((int *)src,(1+N),&Rcount);
      }
      }
      offset=count[j]-tcount[j]+size; /* second processor receives rest */
      size= tcount[j]-size;
      if (size >0) { 
/*
        AIOHPPUT(dpl,(char *)&out[offset],(char *)src,0,(size)*nbytes);
*/
      if (pid==dpl) {
        memcpy((char *)&src[0],(char *)&out[offset],(size)*nbytes);
        Rcount -= size ;
      }
      else {
      temp= out[offset+size];
      out[offset+size]=0;
      MPI_Isend((void *)&out[offset], (1+size),MPI_INT ,dpl,
                1,MPI_COMM_WORLD,&request);
      out[offset+size]=temp;
      Ncheck((int *)src,(1+N),&Rcount);
      }
      }
   }
   }
 }
 while (Rcount !=0)
   Ncheck((int *)src,(1+N),&Rcount);
}
 free ((void *)out);
}
#endif
