/****   Copyright (c) 1997,2001-2003  Alexandros V. Gerbessiotis
 ****
 ****   Permission to use, copy, modify, and distribute this software,
 ****   and to incorporate it, in whole or in part, into other software,
 ****   is hereby granted without fee, provided that
 ****     (1) the above copyright notice and this permission notice appear in
 ****         all copies of the source code, and the above copyright notice
 ****         appear in clearly visible form on all supporting documentation
 ****         and distribution media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects; use this code on your own personal risk
 ****/

#include <memory.h>
#include <limits.h>
#include <math.h>
#include "ai.h"
typedef unsigned int   data;

/* Definitions */
#ifndef TRUE
#define TRUE            1
#endif
#ifndef FALSE
#define	FALSE		0
#endif

#ifndef MIN
#define	MIN(X,Y)	((X)< (Y)?(X):(Y)) 
#endif
#ifndef MAX
#define	MAX(X,Y)	((X)> (Y)?(X):(Y))
#endif
#define CEIL(X,Y)       (((X) != 0)?(1+ ((X)-1)/(Y)):0)  
#define FLOOR(X,Y)      ((X)/(Y))  
#define LEFT(X,Y)       ((X)-((X)/(Y))*(Y))
#define Div2(X)         ((X) >> 1)
#define Tim2(X)         ((X) << 1)
#define Mask(X,Y,Z)     (((X) >> (Y)) & ~(UINT_MAX << (Z)))



extern double __my_estimate_l ;
extern double __my_estimate_g ;
extern int    __my_estimate_nprocs;
extern int    __my_first_call;
extern int    __my_estimate_brd;
extern int    __my_estimate_ppf;
/*	Function declarations */
void __my_estimate_bsp_values(void);
int flg (int x);
int clg (int x);
int Exp2 (int x);
void radixsorti(int n,unsigned int mx_int,int *sbits,int *nbits);
void radixsort (unsigned int *src,int n,unsigned int mx_int);
void int32sort ( unsigned int *src, int n );
void cintsort(unsigned int *src,int n);
void sintsort(unsigned int *src,int n);
void rdxinit(int n,unsigned int mx_int,int *sbits,int *nbits);
void rdx ( unsigned int *src,int n,unsigned int  mx_int );
void rdxint ( unsigned int *src, int n );

int compare(const void  *left,const void *right);

void check_if_null(void *x,char *s,char *t) ;
void __my_estimate_bsp_values() ;
void bspbroad(int fromp, char *from, char *to, int size) ;
void foldmax(double *z, double *x, double *y) ;
void foldmin(double *z, double *x, double *y) ;
void bspfold(void (*operator)(void *,void*,void*),char *from,char *to,int size) ;

void oper_add(data *result, data *left, data *right , int);
void ai2scan(void (*operator)(),int ,char *,char *, char *,int );
void foldsum(int *, int *, int *);
void print_uint(data *, int ,char *);

void    rdx4  (unsigned int *, int);
void  mprdx4 (unsigned int *, int);
void    sbrdx(unsigned int *, int );
void  mpsbrdx(unsigned int *, int );
void    sprdx(unsigned int *, int );
void  mpsprdx(unsigned int *, int );
