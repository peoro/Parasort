/****Copyright (c) 2001-2002  Alexandros V. Gerbessiotis. 
 **** All rights reserved.                               
 ****Permission to use, copy, modify, and distribute this software,
 ****and to incorporate it, in whole or in part, into 
 ****other software,is hereby granted without fee, provided that
 ****  (1) the above copyright notice and this permission 
 ****      notice appear in all copies of the source code, and 
 ****      the above copyright notice appear in clearly visible 
 ****      form on all supporting documentation and distribution 
 ****      media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee, whatsoever, is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects. Use this code at your own personal risk.
 ****/
#ifdef   MPILIB
extern MPI_Comm comm;
extern MPI_Win  win;
extern MPI_Win  aiwin[];
extern void*    bspmpi[];
extern int bspmpi_max ;
extern int bspmpi_first;
extern int bspmpicur_max ;
extern int mpi_pid ;
extern int mpi_nprocs ;
extern double mpi_bsp_l ;
extern double mpi_bsp_g ;
extern double mpi_basetime;

int aisearch (void *);
int aiinsert (void *);
void aidelte (void *);
#endif
