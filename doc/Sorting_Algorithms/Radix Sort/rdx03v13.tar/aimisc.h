/**************************************************************************
 ****  Copyright (c) 2003  Alexandros V. Gerbessiotis
 ****
 ****   Permission to use, copy, modify, and distribute this software,
 ****   and to incorporate it, in whole or in part, into other software,
 ****   is hereby granted without fee, provided that
 ****     (1) the above copyright notice and this permission notice appear in
 ****         all copies of the source code, and the above copyright notice
 ****         appear in clearly visible form on all supporting documentation
 ****         and distribution media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects; use this code on your own personal risk
 ****/

   /* .h file for aimisc.h */
#include <stdlib.h>
#include "ai.h"
#ifndef BRD_CUTOFF
#define BRD_CUTOFF      1200
#endif
#ifndef PPF_CUTOFF
#define PPF_CUTOFF      200
#endif


void check_if_null(void *x,char *s,char *t);

void __my_estimate_bsp_values();

void bspbroad(int fromp, char *from, char *to, int size);

void foldmax(double *z, double *x, double *y);

void foldmin(double *z, double *x, double *y);

void
  bspfold(void (*oper)(void *,void*,void*),char *from,char *to,int size);

