/*****	Constant definitions */
#ifndef TRUE
#define TRUE            1
#endif
#ifndef FALSE
#define	FALSE		0
#endif

/*****	Function Definitions */

#define	MIN(x,y)	((x)<=(y)?(x):(y)) 
#define	MAX(x,y)	((x)>=(y)?(x):(y))
#define CEIL(X,Y)       ((X != 0)?(1+ (X-1)/Y):0)  
#define OLD_CEIL(X,Y)   ((((X/Y)*Y)==X)?(X/Y):(X/Y+1))  
#define FLOOR(X,Y)      (X/Y)  
#define LEFT(x,y)       (x-(x/y)*y)

void check_if_null(void *x,char *s,char *t);
int FLog2 (int x);
int CLog2 (int x);
int Exp2 (int x);
void radixsorti(int n,unsigned int mx_int,int *sbits,int *nbits);
void radixsort (unsigned int *src,int n,unsigned int mx_int);
void int32sort ( unsigned int *src, int n );
void cintsort(unsigned int *src,int n);
void sintsort(unsigned int *src,int n);
void rdxinit(int n,unsigned int mx_int,int *sbits,int *nbits);
void rdx ( unsigned int *src,int n,unsigned int  mx_int );
void rdxint ( unsigned int *src, int n );

int compare(const void  *left,const void *right);
