/****Copyright (c) 2003  Alexandros V. Gerbessiotis.
 **** All rights reserved.
 ****Permission to use, copy, modify, and distribute this software,
 ****and to incorporate it, in whole or in part, into
 ****other software,is hereby granted without fee, provided that
 ****  (1) the above copyright notice and this permission
 ****      notice appear in all copies of the source code, and
 ****      the above copyright notice appear in clearly visible
 ****      form on all supporting documentation and distribution
 ****      media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee, whatsoever, is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects. Use this code at your own personal risk.
 ****/
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <sys/times.h>
#include <unistd.h>
#define bsp_nprocs() 1
#define bsp_pid()    0
#define bsp_begin(X)
#define bsp_end()    
#define bsp_time()  ((double) clock())/((double)CLOCKS_PER_SEC)
/*
#define bsp_time()  (times(&buf), ((double)(buf.tms_utime+buf.tms_stime))/((double)sysconf(_SC_CLK_TCK)))
*/
#define bsp_sync() 
#define bsp_abort(s) fprintf(stderr,s);fflush(stderr)
#define bsp_pushregister(X,Y)
#define bsp_bcast(X,Y,Z,W)
#define bsp_popregister(X) 
#define drand48() ( ((double) rand())/((double) ((unsigned int) 0x7FFFFFFF)))
extern clock_t clock(void);
clock_t times (struct tms *buf);
