/****Copyright (c) 2002-2003  Alexandros V. Gerbessiotis. 
 **** All rights reserved.                               
 ****Permission to use, copy, modify, and distribute this software,
 ****and to incorporate it, in whole or in part, into 
 ****other software,is hereby granted without fee, provided that
 ****  (1) the above copyright notice and this permission 
 ****      notice appear in all copies of the source code, and 
 ****      the above copyright notice appear in clearly visible 
 ****      form on all supporting documentation and distribution 
 ****      media, and
 ****     (2) any redistribution of the software, in original
 ****         or modified form, be without fee and subject to
 ****         these same conditions.
 ****   No guarantee, whatsoever, is offered that the code works as
 ****   advertised or is absent of any, even damaging,
 ****   side-effects. Use this code at your own personal risk.
 ****/
#include "ai.h"
#include "aimpi.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef   MPILIB
#define AIMPIWINMAX   128
MPI_Comm comm;
MPI_Win  win;
MPI_Win  aiwin[AIMPIWINMAX];
void*    bspmpi[AIMPIWINMAX];
int bspmpi_max = AIMPIWINMAX;
int bspmpi_first=1;
int bspmpicur_max = 0;
int mpi_pid = -1;
int mpi_nprocs = -1;
double mpi_bsp_l = 300.0;
double mpi_bsp_g = 0.5;
double mpi_basetime=0.0;
#endif

#ifdef MPILIB
int aisearch(void * address) {
 register int i;

 for (i=bspmpi_max; i >=0; i-- ){
   if (bspmpi[i] == address) {
        return(i);
   }
 }
 return(-1);
}

int aiinsert(void *address) {
 register int i;
 if (bspmpi_first == 1) {
    bspmpi_first =0;
    for(i=0;i<bspmpi_max;i++) {
          bspmpi[i]=NULL;
    }
 }
 for(i=bspmpicur_max; i>=0 ; i--){
  if (bspmpi[i] == NULL)  {
    bspmpi[i]=address;
    bspmpicur_max++;
/*
    if (AIPID()==10) fprintf(stdout,"Iroc %d i=%d %d %u\n",AIPID(),i,bspmpicur_max,address);fflush(stdout);
*/
    return (i);
  }
 }
 /* runout of space */
 return(-1);
}

int aidelete(void *address) {
 register int i;
 for(i=bspmpicur_max-1;i>=0;i--) {
   if (bspmpi[i]==address){
     bspmpi[i]= NULL;
     bspmpicur_max --;
/*
     if (AIPID()==10) fprintf(stdout,"Droc %d i=%d %d %u\n",AIPID(),i,bspmpicur_max,address);fflush(stdout);
*/
     return(i);
   }
 }
 return(-1);
}
#endif
